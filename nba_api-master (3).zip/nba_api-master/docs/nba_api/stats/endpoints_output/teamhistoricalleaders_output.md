CareerLeadersByTeam:

|    TEAM_ID |   PTS |   PTS_PERSON_ID | PTS_PLAYER    |   AST |   AST_PERSON_ID | AST_PLAYER   |   REB |   REB_PERSON_ID | REB_PLAYER    |   BLK |   BLK_PERSON_ID | BLK_PLAYER    |   STL |   STL_PERSON_ID | STL_PLAYER   | SEASON_YEAR   |
|-----------:|------:|----------------:|:--------------|------:|----------------:|:-------------|------:|----------------:|:--------------|------:|----------------:|:--------------|------:|----------------:|:-------------|:--------------|
| 1610612742 | 31560 |            1717 | Dirk Nowitzki |  5111 |             157 | Derek Harper | 11489 |            1717 | Dirk Nowitzki |  1281 |            1717 | Dirk Nowitzki |  1551 |             157 | Derek Harper | 2023-24       |