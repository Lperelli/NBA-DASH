AssistLeaders:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   AST |
|-------:|-----------:|:--------------------|:----------------------|------:|
|      1 | 1610612754 | IND                 | Indiana Pacers        |  2522 |
|      2 | 1610612759 | SAS                 | San Antonio Spurs     |  2449 |
|      3 | 1610612743 | DEN                 | Denver Nuggets        |  2415 |
|      4 | 1610612744 | GSW                 | Golden State Warriors |  2402 |
|      5 | 1610612747 | LAL                 | Los Angeles Lakers    |  2340 |