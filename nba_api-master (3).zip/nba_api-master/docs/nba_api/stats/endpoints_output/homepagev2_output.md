HomePageStat1:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   PTS |
|-------:|-----------:|:--------------------|:----------------------|------:|
|      1 | 1610612754 | IND                 | Indiana Pacers        | 123.3 |
|      2 | 1610612738 | BOS                 | Boston Celtics        | 120.6 |
|      3 | 1610612760 | OKC                 | Oklahoma City Thunder | 120.1 |
|      4 | 1610612749 | MIL                 | Milwaukee Bucks       | 119   |
|      5 | 1610612737 | ATL                 | Atlanta Hawks         | 118.3 |

HomePageStat2:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   REB |
|-------:|-----------:|:--------------------|:----------------------|------:|
|      1 | 1610612744 | GSW                 | Golden State Warriors |  46.7 |
|      2 | 1610612738 | BOS                 | Boston Celtics        |  46.3 |
|      3 | 1610612762 | UTA                 | Utah Jazz             |  45.5 |
|      3 | 1610612745 | HOU                 | Houston Rockets       |  45.5 |
|      5 | 1610612752 | NYK                 | New York Knicks       |  45.2 |

HomePageStat3:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   AST |
|-------:|-----------:|:--------------------|:----------------------|------:|
|      1 | 1610612754 | IND                 | Indiana Pacers        |  30.8 |
|      2 | 1610612759 | SAS                 | San Antonio Spurs     |  29.9 |
|      3 | 1610612743 | DEN                 | Denver Nuggets        |  29.5 |
|      4 | 1610612744 | GSW                 | Golden State Warriors |  29.3 |
|      5 | 1610612747 | LAL                 | Los Angeles Lakers    |  28.5 |

HomePageStat4:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   STL |
|-------:|-----------:|:--------------------|:----------------------|------:|
|      1 | 1610612755 | PHI                 | Philadelphia 76ers    |  8.46 |
|      1 | 1610612760 | OKC                 | Oklahoma City Thunder |  8.46 |
|      3 | 1610612740 | NOP                 | New Orleans Pelicans  |  8.34 |
|      4 | 1610612763 | MEM                 | Memphis Grizzlies     |  8.21 |
|      4 | 1610612753 | ORL                 | Orlando Magic         |  8.16 |

HomePageStat5:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   FG_PCT |
|-------:|-----------:|:--------------------|:----------------------|---------:|
|      1 | 1610612754 | IND                 | Indiana Pacers        |    0.507 |
|      2 | 1610612760 | OKC                 | Oklahoma City Thunder |    0.499 |
|      2 | 1610612747 | LAL                 | Los Angeles Lakers    |    0.499 |
|      4 | 1610612743 | DEN                 | Denver Nuggets        |    0.496 |
|      5 | 1610612756 | PHX                 | Phoenix Suns          |    0.493 |

HomePageStat6:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   FT_PCT |
|-------:|-----------:|:--------------------|:----------------------|---------:|
|      1 | 1610612762 | UTA                 | Utah Jazz             |    0.83  |
|      2 | 1610612755 | PHI                 | Philadelphia 76ers    |    0.826 |
|      3 | 1610612760 | OKC                 | Oklahoma City Thunder |    0.825 |
|      3 | 1610612746 | LAC                 | LA Clippers           |    0.825 |
|      5 | 1610612748 | MIA                 | Miami Heat            |    0.818 |

HomePageStat7:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME              |   FG3_PCT |
|-------:|-----------:|:--------------------|:-----------------------|----------:|
|      1 | 1610612760 | OKC                 | Oklahoma City Thunder  |     0.389 |
|      2 | 1610612738 | BOS                 | Boston Celtics         |     0.388 |
|      3 | 1610612750 | MIN                 | Minnesota Timberwolves |     0.387 |
|      4 | 1610612740 | NOP                 | New Orleans Pelicans   |     0.383 |
|      5 | 1610612756 | PHX                 | Phoenix Suns           |     0.382 |

HomePageStat8:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME              |   BLK |
|-------:|-----------:|:--------------------|:-----------------------|------:|
|      1 | 1610612760 | OKC                 | Oklahoma City Thunder  |  6.56 |
|      1 | 1610612738 | BOS                 | Boston Celtics         |  6.56 |
|      3 | 1610612759 | SAS                 | San Antonio Spurs      |  6.34 |
|      4 | 1610612750 | MIN                 | Minnesota Timberwolves |  6.06 |
|      4 | 1610612763 | MEM                 | Memphis Grizzlies      |  6.11 |