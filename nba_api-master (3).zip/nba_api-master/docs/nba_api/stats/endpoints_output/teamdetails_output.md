TeamBackground:

|    TEAM_ID | ABBREVIATION   | NICKNAME   |   YEARFOUNDED | CITY   | ARENA                    |   ARENACAPACITY | OWNER          | GENERALMANAGER   | HEADCOACH   | DLEAGUEAFFILIATION   |
|-----------:|:---------------|:-----------|--------------:|:-------|:-------------------------|----------------:|:---------------|:-----------------|:------------|:---------------------|
| 1610612742 | DAL            | Mavericks  |          1980 | Dallas | American Airlines Center |           19200 | Patrick Dumont | Nico Harrison    | Jason Kidd  | Texas Legends        |

TeamHistory:

|    TEAM_ID | CITY   | NICKNAME   |   YEARFOUNDED |   YEARACTIVETILL |
|-----------:|:-------|:-----------|--------------:|-----------------:|
| 1610612742 | Dallas | Mavericks  |          1980 |             2023 |

TeamSocialSites:

| ACCOUNTTYPE   | WEBSITE_LINK                        |
|:--------------|:------------------------------------|
| Facebook      | https://www.facebook.com/dallasmavs |
| Instagram     | https://instagram.com/dallasmavs    |
| Twitter       | https://twitter.com/dallasmavs      |

TeamAwardsChampionships:

|   YEARAWARDED | OPPOSITETEAM   |
|--------------:|:---------------|
|          2011 | Miami Heat     |

TeamAwardsConf:

|   YEARAWARDED | OPPOSITETEAM   |
|--------------:|:---------------|
|          2006 |                |
|          2011 |                |

TeamAwardsDiv:

|   YEARAWARDED | OPPOSITETEAM   |
|--------------:|:---------------|
|          1987 |                |
|          2007 |                |
|          2010 |                |
|          2021 |                |

TeamHof:

|   PLAYERID | PLAYER         | POSITION   | JERSEY   | SEASONSWITHTEAM      |   YEAR |
|-----------:|:---------------|:-----------|:---------|:---------------------|-------:|
|       1717 | Dirk Nowitzki  | F-C        |          | 1998-2019            |   2023 |
|        896 | Tim Hardaway   | G          |          | 2002                 |   2022 |
|        467 | Jason Kidd     | G          |          | 1994-1997, 2007-2012 |   2018 |
|        959 | Steve Nash     | G          |          | 1998-2004            |   2018 |
|         23 | Dennis Rodman  | F          |          | 2000                 |   2011 |
|      76504 | Adrian Dantley | F          |          | 1989-1990            |   2008 |
|      76673 | Alex English   | F          |          | 1991                 |   1997 |

TeamRetired:

|   PLAYERID | PLAYER           | POSITION   |   JERSEY | SEASONSWITHTEAM      |   YEAR |
|-----------:|:-----------------|:-----------|---------:|:---------------------|-------:|
|       1717 | Dirk Nowitzki    | F-C        |       41 | 1999-2019            |   2022 |
|        157 | Derek Harper     | G          |       12 | 1983-1994, 1996-1997 |   2018 |
|      76176 | Rolando Blackman | G          |       22 | 1982-1992            |   1999 |
|      76516 | Brad Davis       | G          |       15 | 1981-1992            |   1992 |